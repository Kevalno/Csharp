﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Boxing_Unboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 10;
            Object obj = i;//Boxing
            Console.WriteLine(obj);
            int j = (int)obj; //unboxing
            Console.WriteLine(j);
            Console.Read();
 
        }
    }
}
